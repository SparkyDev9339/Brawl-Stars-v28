from Utils.Writer import Writer


class BattleEndMessage(Writer):

    def __init__(self, client, player, type, result, players):
        super().__init__(client)
        self.id = 23456
        self.player  = player
        self.type    = type
        self.result  = result
        self.players = players

    def encode(self):
        battleend_type = 32
        if self.type == 2:
        	battleend_type = 16        
        
        self.writeVint(self.type)
        self.writeVint(self.result)
        if self.type == 2 and self.result == 1:
        	self.player.trophies += 10
        if self.type == 2 and self.result == 2:
        	self.player.trophies += 8
        if self.type == 2 and self.result == 3:
        	self.player.trophies += 7
        if self.type == 2 and self.result == 4:
        	self.player.trophies += 6
        if self.type == 2 and self.result == 5:
        	self.player.trophies += 4
        if self.type == 2 and self.result == 6:
        	self.player.trophies += 2
        if self.type == 2 and self.result == 7:
        	self.player.trophies += 2
        if self.type == 2 and self.result == 8:
        	self.player.trophies += 1
        if self.type == 2 and self.result == 9:
        	self.player.trophies += 0
        if self.type == 2 and self.result == 10:
        	self.player.trophies += 0
        self.player.updateAccount('Trophies', self.player.trophies) # Save
        self.writeVint(0)
        self.writeVint(0)

        self.writeVint(0)
        self.writeVint(0)
        self.writeVint(0)
        self.writeVint(0)

        self.writeVint(0)
        self.writeVint(0)
        self.writeVint(0)
        self.writeVint(0)

        self.writeVint(0)
        self.writeVint(0)
        self.writeVint(0)
        self.writeVint(0)

        self.writeVint(0)
        self.writeVint(battleend_type) # Battle End Type
        self.writeVint(0)
        self.writeVint(1)

        self.writeVint(len(self.players))

        for player in self.players:
            self.brawler  = self.players[player]['Brawler']
            self.skin     = self.players[player]['Skin']
            self.team     = self.players[player]['Team']
            self.username = self.players[player]['Name']

            if self.type == 5:
                self.writeVint(player) if self.team == 0 else self.writeVint(2)
            else:
                self.writeVint(2 if self.team != 0 else 1) if self.type == 2 else self.writeVint(self.team if self.team != 1 else 2)

            self.writeDataReference(16, self.brawler)if self.brawler != -1 else self.writeVint(0)
            self.writeDataReference(29, self.skin)   if self.skin != -1 else self.writeVint(0)

            self.writeVint(99999)
            self.writeVint(99999)
            self.writeVint(10)

            self.writeBool(False)

            # sub_64DF74
            self.writeString(self.username)
            self.writeVint(100)
            self.writeVint(28000000)
            self.writeVint(43000000)
            self.writeNullVint()


        value = 2
        self.writeVint(value)
        for i in range(value):
            self.writeVint(0) # ???
            self.writeVint(0) # Experience Gained

        # Array 2
        self.writeVint(0)

        # Array 3
        self.writeVint(39) # Milestones Csv ID
        self.writeVint(1) # Ranks Milestone
        self.writeVint(0)
        self.writeVint(0)
        self.writeVint(5) # Experience Milestone
        self.writeVint(5000)

        self.writeDataReference(28, 0)

        self.writeBool(False)

