import time

class EventSlots:
    maps = [
        {
            'ID': 7,
            'Status': 3,
            'Ended': False,
            'Modifier': 0,
            'Timer': 86400,
        },

        {
            'ID': 45,
            'Status': 3,
            'Ended': False,
            'Modifier': 5,
            'Timer': 86400,
        },

        {
            'ID': 4,
            'Status': 3,
            'Ended': False,
            'Modifier': 0,
            'Timer': 86400,
        },

        {
            'ID': 24,
            'Status': 3,
            'Ended': False,
            'Modifier': 0,
            'Timer': 86400,
        },
        

    ]